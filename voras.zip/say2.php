<?
// Используем cURL для формирования HTTP POST-запроса к Google API
// Пакет php5-curl в Debian
$file_to_upload = array('myfile'=>'@current2.flac');
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"https://www.google.com/speech-api/v1/recognize?xjerr=1&client=chromium&lang=ru-RU");
curl_setopt($ch, CURLOPT_POST,1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: audio/x-flac; rate=16000"));
curl_setopt($ch, CURLOPT_POSTFIELDS, $file_to_upload);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
$result=curl_exec ($ch);
curl_close ($ch);

$json_array = json_decode($result, true);
$voice_cmd = $json_array["hypotheses"][0]["utterance"];

        echo $voice_cmd


?>

